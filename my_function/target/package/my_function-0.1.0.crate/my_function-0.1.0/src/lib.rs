
pub fn my_loops(start:i32,end:i32){
    for index in start..end{
        println!("{}",index);
    }
}
